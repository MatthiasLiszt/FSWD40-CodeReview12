function checkScreenSideBar(){
 if(window.innerWidth<800)
  {//alert("small screen");
   $('#mysidebar').addClass('mobilesidebar');
   $('#mysidebar').removeClass('largesidebar');
   $('#primary').addClass('primarysmall');
   $('#primary').removeClass('primarylarge');
   $('#mysidebar').hide();
   var content=$('#mysidebar').html();
   $('#themobilesidebar').html(content);
  }
 else
  {//alert("everything alright");
   $('#mysidebar').addClass('largesidebar');
   $('#mysidebar').removeClass('mobilesidebar');
   $('#primary').removeClass('primarysmall');
   $('#primary').addClass('primarylarge');
   $('#themobilesidebar').hide(content);
   $('#mysidebar').show();
  }
}
